package com.app.service;

import com.app.model.Item;

public interface IItemService {

	public int saveItem(Item item);
}
